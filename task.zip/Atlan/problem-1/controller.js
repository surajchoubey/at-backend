const slangController = (req, res) => {
    try {
        const { word, location } = req.body
        /* 
            alternatively get Mapbox API fetch location by lat and long then find my location string
            this would actually increase the job on client-side frontend-side 

            infact I made something similar sometime ago:
            https://finest-weather-application.herokuapp.com/
        */

        res.status(200).json({
            success: true,
            response: `https://www.google.com/search?q=${word}+meaning+${location}`
        })

    } catch (e) {
        res.status(400).json({
            success: false,
            error: e.message
        })
    }
}

module.exports = { slangController }