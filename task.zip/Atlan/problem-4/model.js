const mongoose = require('mongoose')
const validator = require('validator')

const receiptSchema = new mongoose.Schema({
    name: { 
        type: String, 
        required: true
    },
    ingestion: {
        type: Boolean,
        default: false,
    },
    phonenumber: {
        type: String,
        required: true
    },
    receipt: {
        type: String,
        default: 'Receipt has not been generated yet'
    }
})

receiptSchema.pre('save', async function (next) {
    const receipt = this
    if (receipt.ingestion === true) {
        receipt.receipt = `Receipt successfully generated! Download it from https://receipt.com/${receipt.phonenumber}`
    }
    next()
})

const Receipt = new mongoose.model('Receipt', receiptSchema)

module.exports = Receipt