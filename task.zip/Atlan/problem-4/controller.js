const Receipt = require('./model')

const receiptController = async (req, res) => {
    try {

        if (req.body.receipt) {
            throw new Error('You cannot modify receipt by yourself')
        }

        const receipt = new Receipt(req.body)

        res.status(200).json({
            success: true,
            response: await receipt.save()
        })
    } catch(e) {
        res.status(400).json({
            success: false,
            error: e.message
        })
    }
}

const receiptControllerUpdate = async (req, res) => {
    try {

        if (req.body.receipt) {
            throw new Error('You cannot modify receipt by yourself')
        }

        const receipt = await Receipt.findById(req.params.id)
        
        if (!receipt) {
            throw new Error('Receipt not found by Id')
        }

        for (const key in req.body) {
            receipt[key] = req.body[key]
        }

        res.status(200).send({
            success: true,
            response: await receipt.save()
        })

    } catch (e) {
        res.status(400).send({
            success: false,
            error: e.message
        })
    }
}

module.exports = { receiptController, receiptControllerUpdate }