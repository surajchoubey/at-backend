const fs = require('fs')

const formcheck = (body) => {

    if (body.name.length < 3) {
        throw new Error('Something is wrong with your name')
    }

    if (body.age < 0 || body.income < 0) {
        throw new Error('Age and Income cannot be less than 0')
    }

    if ( !(body.gender === 'M' || body.gender === 'F') ) {
        throw new Error('There are 2 genders only M,F')
    }

}

const formController = async (req, res) => {
    try {

        formcheck(req.body)

        const { name, age, gender, income, country } = req.body;

        const line = `${name};${age};${gender};${income};${country}\n`

        if (!fs.existsSync('responses.csv')) {
            await fs.writeFileSync('responses.csv','Name;Age;Gender;Income\n', (e) => {if (e) throw(e)})
        }

        await fs.appendFileSync('responses.csv', line, (e) => { if(e) throw(e)})

        res.status(200).json({
            success: true,
            response: req.body
        })

    } catch(e) {
        res.status(400).json({
            success: false,
            error: e.message
        })
    }
}

module.exports = { formController }