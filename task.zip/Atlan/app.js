const express = require('express')
const mongoose = require('mongoose')
const router = require('./routes')
const app = express()

const uri = 'mongodb://localhost:27017/atlan-task'

const connectDB = () => {
    mongoose.connect(uri).then(() => {
        console.log('Database Connected! ✅')
    }).catch(e => {
        console.log('Database Connection Failed! ❌')
    }) 
}

connectDB()

app.use(express.json())
app.use(router)

module.exports = app

