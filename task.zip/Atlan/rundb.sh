mkdir db
mongod --dbpath=db