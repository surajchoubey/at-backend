const express = require('express')
const router = express.Router()

const { slangController } = require('./problem-1/controller')
const { employeeController, employeeControllerUpdate } = require('./problem-2/controller')
const { formController } = require('./problem-3/controller')
const { receiptController, receiptControllerUpdate } = require('./problem-4/controller')

router.post('/slangs', slangController)

router.post('/employee', employeeController)
router.patch('/employee/:id', employeeControllerUpdate)

router.post('/organizations', formController)

router.post('/client', receiptController)
router.patch('/client/:id', receiptControllerUpdate)

module.exports = router