const mongoose = require('mongoose')

const employeeSchema = new mongoose.Schema({
    name: { 
        type: String, 
        required: true 
    },
    monthlyincome: { 
        type: Number, 
        required: true 
    },
    monthlysavings: { 
        type: Number, 
        required: true 
    } 
})

function savingsValidation (next, self) {
    const employee = self
    if (employee.monthlysavings > employee.monthlyincome) {
        throw new Error('Monthly Saving cannot be more than monthly income')
    }
    next()
}

employeeSchema.pre('save', async function (next) { savingsValidation(next, this) })

const employee = new mongoose.model('Employee', employeeSchema)

module.exports = employee