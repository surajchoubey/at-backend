const Employee = require('./model')

const employeeController = async (req, res) => {

    try {
        const employee = new Employee(req.body)
        await employee.save()

        res.status(200).send({
            success: true,
            response: employee
        })

    } catch (e) {

        res.status(400).send({
            success: false,
            error: e.message
        })
    }
}

const employeeControllerUpdate = async (req, res) => {
    
    try {
        const employee = await Employee.findByIdAndUpdate(req.params.id)
        
        if (!employee) throw new Error('Employee not found by Id')

        for (const key in req.body) {
            employee[key] = req.body[key]
        }

        await employee.save()

        res.status(200).send({
            success: true,
            response: employee
        })

    } catch (e) {
        res.status(400).send({
            success: false,
            error: e.message
        })
    }
}

module.exports = { employeeController, employeeControllerUpdate }